import express from 'express';

const users = [
  { id: 1, firstname: 'Christopher', lastname: 'Dietz' },
  { id: 2, firstname: 'Gian', lastname: 'Dotti' },
  { id: 3, firstname: 'David', lastname: 'Ehrenberg' },
  { id: 4, firstname: 'Mehmet Ali', lastname: 'Gencay' },
  { id: 5, firstname: 'Mykola', lastname: 'Havrysh' },
];

export const router = express.Router();

router.get('/', (req, res) => {
  res.json(users);
});

router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  const user = users.find((_u) => _u.id === id);
  if (user) {
    res.json(user);
  } else {
    res.status(404).send('Not found');
  }
});
