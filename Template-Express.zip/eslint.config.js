import globals from 'globals';
import pluginJs from '@eslint/js';

export default [
  { languageOptions: { globals: globals.node } },
  pluginJs.configs.all,
  {
    rules: {
      'no-console': 'off',
      'no-magic-numbers': 'off',
      'one-var': 'off',
      'sort-imports': [
        'error',
        {
          allowSeparatedGroups: true,
        },
      ],
      'sort-keys': 'off',
      'func-style': 'off',
    },
  },
];
