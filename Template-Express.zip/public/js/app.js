const liste = document.querySelector('#liste');

fetch('/api/users')
  .then((resp) => resp.json())
  .then((data) => {
    for (const user of data) {
      liste.insertAdjacentHTML('afterbegin', `<li>${user.firstname}`);
    }
  });
