# Projekt Mitbringliste

## Routen / Ansichten

1. URL: `/`, Startseite

    - Banner / Teaser
    - Button oder Link zur Route 2

2. URL: `/create`, Anlegen einer neuen Liste

    Erfassen von
    - Bezeichnung/Titel
    - Email-Adresse

    Mit dem Submit geht es zur Route 3

3. URL: `/liste/id`, Anzeige der Liste inclusive eines
Formulars für einen neuen Beitrag

    Erfassen von:
    - Wer
    - Was
    - Wieviele

    Mit dem Submit landen wir auf Route 4

    Außerdem Tabelle mit den bisherigen Beiträgen

4. URL: `/liste/id/submission-id`, Anzeigen der Liste incl meines Mitbringsel

    Formular wie bei 3. Jetzt aber mit dem vom Benutzer angegeben Beitrag, damit er diesen ändern kann

    Außerdem Tabelle mit den bisherigen Beiträgen

## Backend

Als Backend wird ganz einfach der Typicode Json-Server
genutzt. Also benötigt das Projekt eine *Datenbank* in
Form einer JSON-Datei:

```json
{
    "lists": [],
    "submissions": []
}
```

Die Benennung der Resources (hier `lists` und `submissions` ist natürlich frei wählbar).

Der JSON-Server wird gestartet mit

```sh
npx json-server pfad/zur/db.json
```

Submissions (also die Beiträge) speichern auch die List-Id, um diese der Liste zuzuordnen. Eine Beispiel-Datei liegt im Teams-Kanal.

Idealerweise sollte die Backend-URL von einem Config-Modul exportiert werden, damit sie leicht austauschbar ist.

Datei: `config.ts`

```js
export const backendUrl = 'http://localhost:3000'
```

### Infos zum Erzeugen von Daten

Ihr habt natürlich diesmal zwei Resources (sowohl die Listen
als auch die Beiträge pro Liste). Wenn ihr eine JSON-Datebank
nach meinen Vorgaben angelegt habt, sind das folgende beiden
Resource-URLS:

```
http://localhost:3000/lists
http://localhost:3000/submissions
```

Wichtig ist jetzt im Code, dass ihr diesmal natürlich das Ergebnis
der `POST`-Requests braucht!

Beispiel-Code für das Erzeugen eines Beitrages:

```ts
// In einer async Funtion:
const response = await fetch('http://localhost:3000/submissions', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(submissionData);
})
const createdSubmission = await response.json();
```

Im erzeugten `createdSubmission`-Objekt stecken eure übermittelten Daten drin und die vom JSON-Server vergebene `id`.

### Infos zum Anzeigen der Beiträge einer Liste

Hier muss natürlich gefiltert werden.
Eine URL zum fetch der Submissions einer(!) Liste sieht wie
folgt aus:

`http://localhost:3000/submissions?listId=ec6f`
