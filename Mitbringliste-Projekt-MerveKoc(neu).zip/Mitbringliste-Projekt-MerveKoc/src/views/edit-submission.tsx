import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { backendUrl } from '../config.ts';
import '../css/edit-submission.css';

export default function EditSubmission() {
  const { id, submissionId } = useParams();
  const [submission, setSubmission] = useState(null);
  const [wer, setWer] = useState('');
  const [was, setWas] = useState('');
  const [wieviel, setWieViel] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetch(`${backendUrl}/submissions/${submissionId}`)
      .then((response) => response.json())
      .then((data) => {
        setSubmission(data);
        setWer(data.wer);
        setWas(data.was);
        setWieViel(data.wieviel);
      });
  }, [submissionId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const updatedSubmission = { wer: wer, was: was, wieviel: wieviel };
    await fetch(`${backendUrl}/submissions/${submissionId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updatedSubmission)
    });

    navigate(`/liste/${id}`);
  };

  return (
    <div>
      <h1>Beitrag Ändern</h1>
      {submission && (
        <form onSubmit={handleSubmit}>
          <div>
            <label>Wer kommt: </label>
            <input
              type="text"
              value={wer}
              onChange={(e) => setWer(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Was bringt mit: </label>
            <input
              type="text"
              value={was}
              onChange={(e) => setWas(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Wieviele sind wir:</label>
            <input
              type="number"
              value={wieviel}
              onChange={(e) => setWieViel(e.target.value)}
              required
            />
          </div>
          <button type="submit">Ändern</button>
        </form>
      )}
    </div>
  );
}
