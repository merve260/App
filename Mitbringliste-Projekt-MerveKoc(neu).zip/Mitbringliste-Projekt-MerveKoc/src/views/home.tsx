import { Link } from 'react-router-dom'; 


export default function Home() {
  return (
    <div className="home">
      <div className="banner">
        <h1>Liste & Live</h1>
        <p>Make Any List You Want</p>
      </div>
      
      <div className="actions">
       
        <Link to="/create">
          <button className="create-list-button">Starte mit einer Mitbringliste</button>
        </Link>
      </div>
    </div>
  );
}

