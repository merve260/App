import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { backendUrl } from '../config.ts';
import { List } from '../model/model.ts';  
export default function CreateList() {
  const [title, setTitle] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const newList: List = { title, email }; 

    const response = await fetch(`${backendUrl}/lists`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newList)
    });

    const createdList = await response.json();
    navigate(`/liste/${createdList.id}`);
  };

  return (
    <div>
      <h1>Mitbringliste</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Titel:</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Email-Adresse:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <button type="submit">Anlegen</button>
      </form>
    </div>
  );
}
