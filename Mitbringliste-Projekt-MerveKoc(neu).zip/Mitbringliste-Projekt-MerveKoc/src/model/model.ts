
export interface List {
  id?: string;
  title: string;
  email: string;
}


export interface Submission {
  id?: string;
  listId: string;
  wer: string;
  was: string;
  wieviel: string;
}
