import { Routes, Route } from 'react-router-dom';
import CreateList from './views/create-list';
import ViewList from './views/view-list';
import EditSubmission from './views/edit-submission';
import Home from './views/home';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/create" element={<CreateList />} />
      <Route path="/liste/:id" element={<ViewList />} />
      <Route path="/liste/:id/submission/:submissionId" element={<EditSubmission />} />
    </Routes>
  );
}

export default App;
