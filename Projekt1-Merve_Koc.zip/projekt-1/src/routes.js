import express from 'express';
import { db } from './db/index.js'; 

const router = express.Router();

// GET - Alle Todos abrufen
router.get('/api/todos', (req, res) => {
  db.all('SELECT * FROM todos', [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Fehler in der Datenbank' });
    }

    // Wandelt den "completed"-Wert in Boolean um (0/1 zu true/false)
    const todos = rows.map(row => ({
      ...row,
      completed: !!row.completed, // Konvertiert 0 oder 1 in einen Boolean-Wert
    }));
    // Todos als JSON zurückgeben
    res.json(todos); 
  });
});


// POST - Neues Todo hinzufügen
router.post('/api/todos', (req, res) => {
  const { title, completed = false } = req.body;
  db.run('INSERT INTO todos (title, completed) VALUES (?, ?)', [title, completed ? 1 : 0], function (err) {
    if (err) {
      res.status(500).send('Fehler beim Hinzufügen');
    } else {
      res.json({ id: this.lastID, title, completed });
    }
  });
});

// PUT - Todo vollständig bearbeiten
router.put('/api/todos/:id', (req, res) => {
  const { title, completed } = req.body;

  // Einfache Überprüfung
  if (!title || completed === undefined) {
    return res.status(400).json({ error: 'Title und Completed erforderlich' });
  }

  // completed-Wert in Boolean umwandeln
  const completedValue = completed ? 1 : 0;

  db.run(
    'UPDATE todos SET title = ?, completed = ? WHERE id = ?',
    [title, completedValue, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Fehler beim Bearbeiten' });
      if (this.changes === 0) return res.status(404).json({ error: 'Todo nicht gefunden' });

      res.json({ id: req.params.id, title, completed: !!completed });
    }
  );
});



// PATCH - Todo teilweise bearbeiten
router.patch('/api/todos/:id', (req, res) => {
  const { title, completed } = req.body;

  // Aktuelles Todo aus der Datenbank abrufen
  db.get('SELECT title, completed FROM todos WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Datenbankfehler' });
    if (!row) return res.status(404).json({ error: 'Todo nicht gefunden' });

    // Verwende übergebene Werte, sonst behalte die alten bei
    const updatedTitle = title || row.title;
    const updatedCompleted = completed !== undefined ? (completed ? 1 : 0) : row.completed;

    db.run(
      'UPDATE todos SET title = ?, completed = ? WHERE id = ?',
      [updatedTitle, updatedCompleted, req.params.id],
      function (err) {
        if (err) return res.status(500).json({ error: 'Datenbankfehler' });
        if (this.changes === 0) return res.status(404).json({ error: 'Todo nicht gefunden' });

        res.json({ id: req.params.id, title: updatedTitle, completed: !!updatedCompleted });
      }
    );
  });
});




// DELETE - Todo löschen
router.delete('/api/todos/:id', (req, res) => {
  db.run('DELETE FROM todos WHERE id = ?', req.params.id, function (err) {
    if (err) {
      res.status(500).send('Fehler beim Löschen');
    } else {
      res.send('Todo wurde gelöscht');
    }
  });
});

export default router;
