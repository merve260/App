import sqlite3 from 'sqlite3';

// Verbindung zur SQLite-Datenbank herstellen
const db = new sqlite3.Database(import.meta.dirname + '/todos.db');

// Funktion zum Erstellen der Tabelle 'todos'
  db.run(`CREATE TABLE IF NOT EXISTS todos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    completed BOOLEAN
  )`, (err) => {
    if (err) {
      console.error('Fehler beim Erstellen der Tabelle: ', err.message);
    } else {
      console.log('Tabelle "todos" erfolgreich erstellt.');
    }
  });
