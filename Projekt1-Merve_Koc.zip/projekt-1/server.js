import path from 'node:path';
import { fileURLToPath } from 'url';
import express from 'express';
import morgan from 'morgan';
import todoRoutes from './src/routes.js'; // Routen aus der Datei src/routes.js laden



const app = express();


// ES module: __dirname definieren
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middlewares
app.use(morgan('tiny'));
app.use(express.json());


// Routing
// Your starting point. Enjoy the ride


// Routen verwenden
app.use(todoRoutes);

// Static Files Middleware
app.use(express.static(path.join(__dirname, 'public')));

// Start server
const port = 3000;
app.listen(port, () => {
  console.info(`Server started at http://localhost:${port}`);
});
