# Planung: Taschenrechner mit TypeScript

## Programm-Plan

Der Taschenrechner ermöglicht es dem Benutzer, einfache mathematische Operationen (Addition, Subtraktion, Multiplikation und Division) durchzuführen. Die aktuelle Eingabe und das vorherige Ergebnis werden angezeigt. Der Benutzer kann Zahlen, Operatoren und Sonderzeichen (wie `.` für Dezimalstellen) eingeben und die Berechnung durch Drücken der `=`-Taste ausführen.

### Grundlegende Funktionalität

- **Zahlen hinzufügen:** Benutzer kann Zahlen eingeben.
- **Operationen auswählen:** Benutzer kann eine mathematische Operation auswählen.
- **Berechnung durchführen:** Drücken der `=`-Taste führt die Berechnung durch.
- **Eingaben löschen:** Mit `Clr.` werden alle Eingaben gelöscht.
- **Letzte Eingabe entfernen:** Mit `←` wird die letzte Eingabe entfernt.

## zu klärende Fragen

Q: Welche Fehleingaben sind vom Benutzer zu erwarten und wie werden diese abgefangen?

A:
- Mehrere Dezimalstellen in einer Zahl.
- Eingabe einer Operation ohne vorherige Zahl.
- Unvollständige Berechnungen (z.B. `5 +` ohne die zweite Zahl).

Diese Eingaben werden durch logische Bedingungen innerhalb der entsprechenden Methoden (`zahlHinzufuegen`, `operationWaehlen`, etc.) abgefangen.

## Übersicht der Variablen, Konstanten und Funktionen

### TypeScript-Datei

| Bezeichner            | Bemerkung |
|-----------------------|-----------|
| `CalculatorElements`  | Interface, das die HTML-Elemente definiert, die für den Taschenrechner verwendet werden |
| `BaseRechner`         | Abstrakte Klasse, die die grundlegende Taschenrechner-Logik enthält |
| `_aktuellesOperand`   | Privates Feld für den aktuellen Operand |
| `_vorherigesOperand`  | Privates Feld für den vorherigen Operand |
| `_operation`          | Privates Feld für die ausgewählte Operation |
| `aktuellesOperand`    | Getter und Setter für den aktuellen Operand |
| `vorherigesOperand`   | Getter und Setter für den vorherigen Operand |
| `operation`           | Getter und Setter für die ausgewählte Operation |
| `loeschen()`          | Funktion zum Löschen aller Eingaben |
| `entfernen()`         | Funktion zum Entfernen der letzten Zahl |
| `zahlHinzufuegen()`   | Funktion zum Hinzufügen einer Zahl oder eines Dezimalpunkts |
| `operationWaehlen()`  | Funktion zur Auswahl einer Operation |
| `berechnen()`         | Abstrakte Methode zur Durchführung der Berechnung |
| `displayAktualisieren()` | Funktion zur Aktualisierung der Anzeige |
| `AdvancedRechner`     | Klasse, die die Berechnungslogik implementiert |
| `addNumberButtonListeners()` | Funktion zum Hinzufügen von Event-Listenern für die Zahlentasten |
| `addOperatorButtonListeners()` | Funktion zum Hinzufügen von Event-Listenern für die Operationstasten |
| `addControlButtonListeners()` | Funktion zum Hinzufügen von Event-Listenern für die Kontrolltasten |

### Ordner-Struktur

- controller.js
- controller.ts
- calc.md
- PAP-Calc
