"use strict";
class Rechner {
    constructor(vorherigesTextElement, aktuellesTextElement) {
        this.vorherigesTextElement = vorherigesTextElement;
        this.aktuellesTextElement = aktuellesTextElement;
        this.aktuellesOperand = '';
        this.vorherigesOperand = '';
        this.operation = null;
    }
    loeschen() {
        this.aktuellesOperand = '';
        this.vorherigesOperand = '';
        this.operation = null;
    }
    entfernen() {
        this.aktuellesOperand = this.aktuellesOperand.toString().slice(0, -1);
    }
    zahlHinzufuegen(zahl) {
        if (zahl === '.' && this.aktuellesOperand.indexOf('.') !== -1)
            return;
        this.aktuellesOperand = this.aktuellesOperand.toString() + zahl.toString();
    }
    operationWaehlen(operation) {
        if (this.aktuellesOperand === '')
            return;
        if (this.vorherigesOperand !== '') {
            this.berechnen();
        }
        this.operation = operation;
        this.vorherigesOperand = this.aktuellesOperand;
        this.aktuellesOperand = '';
    }
    berechnen() {
        let berechnung;
        const vorherig = parseFloat(this.vorherigesOperand);
        const aktuell = parseFloat(this.aktuellesOperand);
        if (isNaN(vorherig) || isNaN(aktuell))
            return;
        switch (this.operation) {
            case '+':
                berechnung = vorherig + aktuell;
                break;
            case '-':
                berechnung = vorherig - aktuell;
                break;
            case '*':
                berechnung = vorherig * aktuell;
                break;
            case '/':
                berechnung = vorherig / aktuell;
                break;
            default:
                return;
        }
        this.aktuellesOperand = berechnung.toString();
        this.operation = null;
        this.vorherigesOperand = '';
    }
    displayAktualisieren() {
        this.aktuellesTextElement.innerText = this.aktuellesOperand;
        if (this.operation != null) {
            this.vorherigesTextElement.innerText = `${this.vorherigesOperand} ${this.operation}`;
        }
        else {
            this.vorherigesTextElement.innerText = '';
        }
    }
}
// *HTML-Elemente auswählen
const vorherigesTextElement = document.querySelector('[data-previous-output]');
const aktuellesTextElement = document.querySelector('[data-current-output]');
const zahlenButtons = document.querySelectorAll('[data-number]');
const operationsButtons = document.querySelectorAll('[data-operator]');
const gleichButton = document.querySelector('[data-equals]');
const loeschenButton = document.querySelector('[data-clear]');
const entfernenButton = document.querySelector('[data-delete]');
// *Rechner-Klasse instanziieren
const rechner = new Rechner(vorherigesTextElement, aktuellesTextElement);
// *Event Listener hinzufügen
zahlenButtons.forEach(button => {
    button.addEventListener('click', () => {
        rechner.zahlHinzufuegen(button.textContent);
        rechner.displayAktualisieren();
    });
});
operationsButtons.forEach(button => {
    button.addEventListener('click', () => {
        rechner.operationWaehlen(button.textContent);
        rechner.displayAktualisieren();
    });
});
gleichButton?.addEventListener('click', button => {
    rechner.berechnen();
    rechner.displayAktualisieren();
});
loeschenButton?.addEventListener('click', button => {
    rechner.loeschen();
    rechner.displayAktualisieren();
});
entfernenButton?.addEventListener('click', button => {
    rechner.entfernen();
    rechner.displayAktualisieren();
});
