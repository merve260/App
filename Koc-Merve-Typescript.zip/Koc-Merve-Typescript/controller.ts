// *HTML-Elemente definieren
interface CalculatorElements {
  previousOutput: HTMLElement;
  currentOutput: HTMLElement;
  numberButtons: NodeListOf<HTMLElement>;
  operatorButtons: NodeListOf<HTMLElement>;
  equalsButton: HTMLElement;
  clearButton: HTMLElement;
  deleteButton: HTMLElement;
}

// *Abstract BaseRechner Klasse, um grundlegende Funktionalität zu definieren
abstract class BaseRechner {
  private _aktuellesOperand: string = '';
  private _vorherigesOperand: string = '';
  private _operation: string | null = null;

  constructor(protected elements: CalculatorElements) {}

  // *Getter und Setter für die Operanden und die Operation
  get aktuellesOperand(): string {
    return this._aktuellesOperand;
  }

  set aktuellesOperand(value: string) {
    this._aktuellesOperand = value;
    this.displayAktualisieren();
  }

  get vorherigesOperand(): string {
    return this._vorherigesOperand;
  }

  set vorherigesOperand(value: string) {
    this._vorherigesOperand = value;
    this.displayAktualisieren();
  }

  get operation(): string | null {
    return this._operation;
  }

  set operation(value: string | null) {
    this._operation = value;
    this.displayAktualisieren();
  }

  // *Funktion zum Löschen aller Eingaben
  loeschen() {
    this.aktuellesOperand = '';
    this.vorherigesOperand = '';
    this.operation = null;
  }

  // *Funktion zum Entfernen der letzten Zahl
  entfernen() {
    this.aktuellesOperand = this.aktuellesOperand.slice(0, -1);
  }

  // *Funktion zum Hinzufügen einer Zahl
  zahlHinzufuegen(zahl: string) {
    if (zahl === '.' && this._aktuellesOperand.indexOf('.') !== -1) return;
    this.aktuellesOperand += zahl;
  }

  // *Funktion zur Auswahl einer Operation
  operationWaehlen(operation: string) {
    if (!this.aktuellesOperand) return;
    if (this.vorherigesOperand) {
      this.berechnen();
    }
    this.operation = operation;
    this.vorherigesOperand = this.aktuellesOperand;
    this.aktuellesOperand = '';
  }

  // *Abstrakte Methode zur Durchführung der Berechnung
  abstract berechnen(): void;

  // *Funktion zur Aktualisierung der Anzeige
  displayAktualisieren() {
    this.elements.currentOutput.innerText = this.aktuellesOperand;
    this.elements.previousOutput.innerText = this.operation
      ? `${this.vorherigesOperand} ${this.operation}`
      : '';
  }
}

// *AdvancedRechner Klasse, die die Berechnungsmethoden implementiert
class AdvancedRechner extends BaseRechner {
  // *Implementierung der Berechnungslogik
  berechnen() {
    const vorherig = parseFloat(this.vorherigesOperand);
    const aktuell = parseFloat(this.aktuellesOperand);
    if (isNaN(vorherig) || isNaN(aktuell) || this.operation === null) return;

    const operations: { [key: string]: (a: number, b: number) => number } = {
      '+': (a, b) => a + b,
      '-': (a, b) => a - b,
      '*': (a, b) => a * b,
      '/': (a, b) => a / b,
    };

    const berechnung = operations[this.operation](vorherig, aktuell);

    this.aktuellesOperand = berechnung.toString();
    this.operation = null;
    this.vorherigesOperand = '';
  }
}

// *HTML-Elemente aus dem DOM auswählen
const elements: CalculatorElements = {
  previousOutput: document.querySelector('[data-previous-output]') as HTMLElement,
  currentOutput: document.querySelector('[data-current-output]') as HTMLElement,
  numberButtons: document.querySelectorAll('[data-number]'),
  operatorButtons: document.querySelectorAll('[data-operator]'),
  equalsButton: document.querySelector('[data-equals]') as HTMLElement,
  clearButton: document.querySelector('[data-clear]') as HTMLElement,
  deleteButton: document.querySelector('[data-delete]') as HTMLElement,
};

// *Rechner-Klasse instanziieren
const rechner = new AdvancedRechner(elements);

// *Funktion zum Hinzufügen der Event-Listener für die Nummerntasten
function addNumberButtonListeners(buttons: NodeListOf<HTMLElement>) {
  buttons.forEach(button => {
    button.addEventListener('click', () => {
      rechner.zahlHinzufuegen(button.textContent!);
    });
  });
}

// *Funktion zum Hinzufügen der Event-Listener für die Operationstasten
function addOperatorButtonListeners(buttons: NodeListOf<HTMLElement>) {
  buttons.forEach(button => {
    button.addEventListener('click', () => {
      rechner.operationWaehlen(button.textContent!);
    });
  });
}

// *Funktion zum Hinzufügen der Event-Listener für die Kontrolltasten
function addControlButtonListeners() {
  elements.equalsButton.addEventListener('click', () => {
    rechner.berechnen();
  });

  elements.clearButton.addEventListener('click', () => {
    rechner.loeschen();
  });

  elements.deleteButton.addEventListener('click', () => {
    rechner.entfernen();
  });
}

// *Event-Listener für alle Tasten hinzufügen
addNumberButtonListeners(elements.numberButtons);
addOperatorButtonListeners(elements.operatorButtons);
addControlButtonListeners();
