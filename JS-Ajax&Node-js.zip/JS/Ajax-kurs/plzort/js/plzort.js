"use strict";

const objXHR = new XMLHttpRequest();

function fnUpdatePage() {
    let objResponse = null;
    let strOutput = "";

    if (objXHR.readyState === 4 && objXHR.status === 200) {
        if (!objXHR.responseText) {
            strOutput = "Bitte (noch) ein Zeichnen eingeben!";
        } else {
            objResponse = JSON.parse(objXHR.responseText);
            strOutput = '<table class="table">';

            for (let i in objResponse) {
                strOutput += "<tr>";
                strOutput += '<td>' + objResponse[i].ort + '</td>';
                strOutput += '<td>' + objResponse[i].plz + '</td>';
                strOutput += '<td>' + objResponse[i].bundesland + '</td>';
                strOutput += "</tr>";
            }
            strOutput += '</table>';

        }
        document.querySelector("#antwort").innerHTML = strOutput;
   
    }
}

function fnCallPhp() {
    const strInput = document.querySelector("#eingabe").value;
    const strUri = "include/booklist.php?q=" + encodeURI(strInput);

    objXHR.open("get", strUri);
    objXHR.onreadystatechange = fnUpdatePage;
    objXHR.send(null);
}

function fnInit() {
    document.querySelector("#eingabe").addEventListener("keyup", fnCallPhp);
}

document.addEventListener("DOMContentLoaded", fnInit);
