# Planung Postleitzahlen und Orte finden

## Programm-Plan

Der User gibt in das Eingabefeld Buchstaben oder Zahlen ein, je nachdem ob er nach einem Ort oder einer PLZ sucht.

Bei jedem Buchstaben wird im Ausgabebereich bereits die Tabelle ausgegeben, welche zu der eingegebenen Zeichenkette passt. Mit jedem weiteren Buchstaben / jeder weiteren Zahl wird die Tabelle weiter gefiltert. Die Tabelle besteht dabei aus 3 Spalten (Ort, PLZ, Bundesland). Die Tabelle benötigt keine Kopfzeile.

Die Zeichenkette aus dem Eingabefeld wird vom JS-Script entgegengenommen und an den Webserver weitergeleitet.

Das PHP-Script nimmt die Eingabe entgegen und wird die Suche in der CSV-Datei durchführen. Dann liefert das PHP-Script die gefilterten Zeilen der CSV-Datei und sendet sie an das JS-Script zurück.

Das JS-Script gibt die gefilterte Tabelle in den Ausgabebereich aus.

Bei leerem Eingabefeld bleibt der Ausgabebereich leer.

## zu klärende Fragen

Q: Welche Fehleingaben sind vom User zu erwarten und wie werden diese abgefangen?

A:
- Feststelltaste aktiviert
- falsche Zeichen, Sonderzeichen, zu viele Zeichen
- Buchstabendreher
- führende Leerzeichen

Alle Fehleingaben führen in der Regel zu keinem Suchergebnis. D.h. das Ausgabefeld bliebe leer. Alternativ kann darüber eine Meldung im Ausgabefeld ausgegeben werden.

Sollte sicherheitsrelevante böswillige Eingaben erfolgen sind diese durch die entsprechenden nativen JS bzw. PHP-Funktionen zu fixen.

Q: Welches Skript (JS oder PHP) ist für die HTML-Tabellenstruktur Verantwortlich?

A: JavaScript, weil weniger Datenverkehr und dadurch bessere Performance.

Q: In welcher Form soll das Ergebnis der Suche vom PHP-Script geliefert werden?

A: JSON-String.

## Pseudocode

### JavaScript

- DOM schützen
- XHR-Objekt erzeugen
- Variablen / Konstanten für Eingabe- und das Ausgabefeld initialisieren
- Eventhandler (bei Betätigung einer Taste) für das Eingabefeld registrieren und auf Callback-Funktion referenzieren.
- Callback-Funktion:
  - kompletter Inhalt aus dem Textfeld in Konstante speichern
  - Inhalt validieren
  - Die Anfrage vorbereiten (Verbindung öffnen), Methode festlegen (get), angeforderten Dateipfad übergeben (plzort.php), zu sendenden Daten übergeben
  - Anfrage senden
- Prüfen ob die Antwort des Server-Skripts vollständig eingetroffen ist
  - wenn nein: weiter warten
  - wenn ja: nächster Schritt
- Prüfe auf Fehler des JSON-Parsers
  - wenn Fehler: keine Ausgabe, Meldung ausgeben
  - sonst: nächster Schritt
- JSON-Objekt erzeugen
- Ausgabe-Variable mit dem öffnenden table-Tag anlegen
- Schleife über das JSON-Objekt
  - HTML-Tags für die Zeile anlegen
  - jede Eigenschaft mit HTML-Zellen-Tags umschließen
  - Zeilenstruktur an die Ausgabe-Variable anhängen
- schließendes table-Tag an die Ausgabe-Variable anhängen
- Ausgabe-Variable im Ausgabe-Bereich ausgeben

## PHP

- Prüfe ob Infos geliefert wurden (ist $_GET leer?)
  - ist leer: Meldung ausgeben, Abbruch
  - ist nicht leer: weiter mit nächstem Schritt
- Infos aufräumen (trim)
- Prüfe ob eine leere Info geliefert wurde
  - Ja: Meldung und Abbruch
  - Nein: weiter mit nächstem Schritt
- CSV-Datei öffnen
- Prüfe ob die Öffnung erfolgreich war
  - Nein: Meldung und Abbruch
  - Ja: weiter mit nächstem Schritt
- Ausgabe-Array-Variable initialisieren
- Schleife, in welcher die CSV-Datei zeilenweise ausgelesen wird
  - Anweisungsblock der Schleifen
    - ersten Durchlauf ignorieren (Überschriften)
    - Prüfen ob die gelierte Zeichenkette mit den ersten Zeichen der Spalte Ort **ODER** mit den ersten Zeichen der Spalte plz übereinstimmen
      - Ja: die Spalten Ort, PLZ und Bundesland als Array an das Ausgabe-Array angehängt
  - Ende Anweisungsblocks
- Das zweidimensionale Ausgabe-Array in einen JSON-String konvertieren
  - Struktur des Ausgabe-Arrays
  ```
  Array (
    [0] => Array( 'ort' => 'Aachen', 'plz' => '12345', 'bundesland' => 'Bundesland'),
    [1] => Array( 'ort' => '...', 'plz' => '...', 'bundesland' => '...'),
    ...
  )
  ```
- JSON-String an das XHR-Objekt zurückliefern
- CSV-Datei schließen

## Übersicht der Variablen, Konstanten und Funktionen

### JavaScript-Datei

| Bezeichner | Bemerkung |
|------------|-----------|
| `const objXHR` | `XMLHttpRequext`- Objekt |
| `const strInput` | Inhalt aus dem Eingabefeld |
| `let strOutput` | Die HTML-Tabelle |
| `const objJSON` | Das von PHP-Gelieferte JSON-Objekt |
| `const strUri` | angeforderte PHP-Datei (Pfad) + URI-Query-String |
| `fnCallPhp()` | Callback-Funktion zum Event `keyUp` |
| `fnUpdatePage()` | Callback-Funktion zum Event `readystatechange` / `load` |
| `fnInit()` | Callback-Funktion zu DOM-Schutz |

### PHP-Datei

| Bezeichner | Bemerkung |
|------------|-----------|
| `$_GET` | Superglobales ass. Array mit übergebener Zeichenkette im Key `q` |
| `$strSearch` | gespeicherte Suchbegriff aus `$_GET` |
| `$strCSV` | Pfad zur CSV-Datei |
| `$fp` | Dateizeiger auf die CSV-Datei |
| `$arrRow` | Schleifenvariable für Zeilen-Array |
| `$arrOutput` | Array mit gefilterten Daten aus der CSV-Datei |

## Ordner-Struktur

- index.html
- include
  - plzort.php
  - zuordnung_plz_ort.csv
- css
  - bootstrap.min.css
  - style.css
- js
  - plzort.js

