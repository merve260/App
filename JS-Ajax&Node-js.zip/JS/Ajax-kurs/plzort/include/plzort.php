<?php 


if (empty($_GET)) {
    header('Location: ../index.html'); // 
    exit;
} 


if (empty($_GET['q'])) {
    echo null;
    exit;
} else {
    $strSearch = $_GET['q'];
}


$strCSV = 'zuordnung_plz_ort.csv';


$fp = fopen($strCSV, 'r');


if (!$fp) {
    echo json_encode('{ 0: "Datei <b>' . $strCSV . '</b> nicht gefunden" }');
    exit;
}

$arrOutput = array();
$i = 0;


while ($arrRow = fgetcsv($fp)) {
    if ($i === 0) {
        // İlk satır başlıkları atla
        $i++;
        continue;
    }


    if (preg_match("/^$strSearch/i", $arrRow[1]) || preg_match("/^$strSearch/i", $arrRow[2])) {
        $arrOutput[] = array(
            'ort' => $arrRow[1],       // Şehir ismi
            'plz' => $arrRow[2],       // Posta kodu
            'bundesland' => $arrRow[3] // Eyalet
        );
    }
}


echo json_encode($arrOutput);


fclose($fp);

