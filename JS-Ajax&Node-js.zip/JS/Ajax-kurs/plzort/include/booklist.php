<?php
require_once "pdo-connect.inc.php";

header('Content-Type: application/json');

if (empty($_GET)) {
  header('Location: ../index.html');
  exit;
}

if (empty($_GET['q'])) {
  echo json_encode(['err' => 'Kein Suchbegriff eingegeben.']);
  exit;
} else {
  $strSearch = '%' . $_GET['q'] . '%';
}

$arrOutput = [];

$sql = 'SELECT `id`, `isbn`, `title`, `author`, `publisher`, `image` FROM `items` WHERE `title` LIKE :t';

try {
  if ($stmt = $pdo->prepare($sql)) {
    $stmt->bindParam(':t', $strSearch);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
      $arrOutput = [['err' => 'Keine Datensätze gefunden.']];
    } else {
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $arrOutput[] = $row;
      }
    }
  }
} catch (PDOException $e) {
  $arrOutput = [['err' => $e->getMessage()]];
}

echo json_encode($arrOutput, JSON_UNESCAPED_UNICODE);

$stmt = null;
$pdo = null;
