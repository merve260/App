let xhr = new XMLHttpRequest();

function sndReq(i) {
  xhr.onload = () => { handleResponse(i); }
  xhr.open("get", "info.xml");
  xhr.send(null);
}

function handleResponse(i) {
  let daten = null;
  document.querySelector("#debug").innerHTML = xhr.responseText;

  daten = xhr.responseXML;
  console.log(daten);
  //Die richtigen Daten aus dem XML-DOM Objekt Laden
  document.querySelector("#info" + i).innerHTML = daten.querySelectorAll("info")[i].innerHTML;
}

function out(i) {
  info = document.querySelector("#info" + i).innerHTML = "";
  
}

function init() {
  const images = document.querySelectorAll("img");
  
  
  for( let i = 0; i < images.length; i++) {
    images[i].addEventListener("mouseover", _ => { sndReq(i); });
    images[i].addEventListener("mouseout", _ => { out(i); });
  }
}

document.addEventListener("DOMContentLoaded", init);