let xhr = new XMLHttpRequest();

function sndReq(i) {
  xhr.onload = _ => { handleResponse(i); }

  switch (i) {
    case 0:
      xhr.open("get", "info0.txt");
      break;
    case 1:
      xhr.open("get", "info1.txt");
      break;
    case 2:
      xhr.open("get", "info2.txt");
  }


  xhr.send(null);
}

function handleResponse(i) {
  let info = "";
  switch (i) {
    case 0:
      info = document.querySelector('#info0');
      break;
    case 1:
      info = document.querySelector('#info1');
      break;
    case 2:
      info = document.querySelector('#info2');
  }
  info.innerHTML = xhr.responseText;
}

function out(i) {

}

function getXhrError() {
  console.log("Error: " + xhr.status);
}

function init() {
  const images = document.querySelectorAll("img");
  for( let i = 0; i < images.length; i++) {
    images[i].addEventListener("mouseover", _ => { sndReq(i); });
    images[i].addEventListener("mouseout", _ => { out(i); });
  }
}

document.addEventListener("DOMContentLoaded", init);