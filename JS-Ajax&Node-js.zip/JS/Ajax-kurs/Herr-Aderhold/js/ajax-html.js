let xhr = new XMLHttpRequest();

function sndReq() {
  xhr.onload = handleResponse;
  xhr.open("get", "antwort-html.text");
  xhr.send(null);
  xhr.oneerror = getXhrError;
}

function handleResponse() {
  if (xhr.status === 200) {
    document.querySelector("#antwort").innerHTML=xhr.
  }
}

function getXhrError() {
  console.log("Error: " + xhr.status);
}

function init() {
  document.querySelector("#frage").addEventListener("click", sndReq);
}

document.addEventListener("DOMContentLoaded", init);