let xhr = new XMLHttpRequest();

function sndReq(i) {
  xhr.open('get', 'info-json.txt', true);
  xhr.onload = _ => { handleResponse(i); }
  
  xhr.send(null);
}

function handleResponse(i) {
  let daten = null;

  console.log(xhr.responseType);

  if (xhr.responseType === "json") {
    daten = xhr.response;
  } else {
    daten = JSON.parse(xhr.responseText);
  }
  console.log(daten);
}

function out(i) {
  document.querySelector("#info" + i).innerHTML = "";
}

function init() {
  const images = document.querySelectorAll("img");
  for (let i = 0; i < images.length; i++) {
    images[i].addEventListener("mouseover", _ => { sndReq(i); });
    images[i].addEventListener("mouseout", _ => { out(i); });
  }
}

document.addEventListener("DOMContentLoaded", init);