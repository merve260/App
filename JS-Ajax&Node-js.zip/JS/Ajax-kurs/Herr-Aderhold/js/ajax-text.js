// Erzeuge ein XHR-Objekt
const xhr = new XMLHttpRequest();

function sndReq() {
  // 2. Callback-Funktion registrieren
  xhr.onload = handleResponse;

  // 3. Verbindung zum Server öffnen
  xhr.open("get", "antwort.txt");

  // 4. Anfrage abschicken und auf Antwort warten
  xhr.send(null);
}

function handleResponse() {
  // 5. Verarbeitung der Antwort des Servers
  let antwort = document.querySelector('#antwort');

  antwort.innerHTML = xhr.responseText;

  antwort.innerHTML += "<br>Status: " + xhr.status + "<br>Status-Text: " + xhr.statusText + "<br>Header-Infos: " + xhr.getAllResponseHeaders();
}

function init() {
  document.querySelector("#frage").addEventListener("click", sndReq);
}

document.addEventListener("DOMContentLoaded", init);