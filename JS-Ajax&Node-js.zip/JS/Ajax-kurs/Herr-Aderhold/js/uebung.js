let xhr = new XMLHttpRequest();

function sndReq(i) {
    xhr.onload = () => { handleResponse(i); }
    xhr.open("GET", "uebung10_7.xml");
    xhr.send(null);
}

function handleResponse(i) {
    let websiten = xhr.responseXML;
    if (websiten) {
        
        let seite = websiten.querySelectorAll("seite")[i];
        if (seite) {
          
            let titel = seite.querySelector("titel").textContent;
            let url = seite.querySelector("url").textContent;
            let bemerkung = seite.querySelector("bemerkung").textContent;

            
            document.querySelector("#seite" + i).innerHTML = "Titel: " + titel;
            document.querySelector("#title" + i).innerHTML = "URL: " + url;
            document.querySelector("#url" + i).innerHTML = "URL: " + url;
            document.querySelector("#bemerkung" + i).innerHTML = "Bemerkung: " + bemerkung;
        }
    }
}

function out(i) {
    // HTML elemanlarının içeriğini temizliyoruz
    document.querySelector("#seite" + i).innerHTML = "";
    document.querySelector("#title" + i).innerHTML = "";
    document.querySelector("#url" + i).innerHTML = "";
    document.querySelector("#bemerkung" + i).innerHTML = "";
}

function init() {
 
    let images = document.querySelectorAll("img");
    for (let i = 0; i < images.length; i++) {
        images[i].addEventListener("mouseover", _ => { sndReq(i); });
        images[i].addEventListener("mouseout", _ => { out(i); });
    }
}

document.addEventListener("DOMContentLoaded", init);
