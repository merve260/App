let xhr = new XMLHttpRequest();

function handleResponse() {
  document.querySelector("#antwort").innerHTML = xhr.responseText;
}

function sndReqGET() {
  // Parameter zum Senden in Variable ablegen
  let params = encodeURI("user=admin&password=geheim");
  // GET-Verbindung öffnen
  xhr.open("get", "ajax.php?" + params);
  xhr.onload = handleResponse;
  xhr.send(null);

}

function sndReqPOST() {
  // Parameter zum Senden an Variable ablegen
  let params = encodeURI("iban=DE12 3456 78 0987 6543 21&SWIFT=FFDEX12XXX");
  console.log(params);
  
  

  // POST-Verbindung öffnen
  xhr.open("post", "ajax.php"); 

  // Header-Info zum Mime-Type der gesendeten Parameter festlagen
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  // Header-Info zur Länge der gesendeten Daten festlegen
  //xhr.setRequestHeader("Content-length", params.length);

  // Funktion referenzieren bei Änderung des Status der Server-Antwort
  xhr.onload = handleResponse

  // Daten mit angehängten Parametern senden
  xhr.send(params);
}

function init() {
  document.querySelector("#sendeget").addEventListener("click", sndReqGET);
  document.querySelector("#sendepost").addEventListener("click", sndReqPOST);
}

document.addEventListener("DOMContentLoaded", init);










