function erzXHRObjekt() {
  let responseObject = null; // das XHR-Objekt

  try {
    responseObject = new ActiveXObject("Microsoft.XMLHTTP");
  } catch(e) {
    try {
      responseObject = new ActiveXObject("MSXML2.XMLHTTP");
    } catch(e) {
      try {
        // Standardisierte Variante des W3C
        responseObject = new XMLHttpRequest();
      } catch(e) {
        alert("Erzeugung des XMLHttpRequest-Objektes fehlgeschlagen.");
        return false;
      }
    }
  }

  return responseObject;
}