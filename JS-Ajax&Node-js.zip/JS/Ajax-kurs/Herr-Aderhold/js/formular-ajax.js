/* (globale) Variablen definieren */

let loginForm;
let user;
let userinfo;
let pw;
let pwinfo;
let logout;
let frage;
let zurueck;
let resObj;
let antwort;

function sndReq() {
	let params = encodeURI("user=" + user.value + "&pw=" + pw.value);
	resObj.open("get", "ajax.php?" + params);
	resObj.onreadystatechange = handleResponse;
	resObj.send(null);
}

function handleResponse() {
	if (resObj.readyState === 4 && resObj.status === 200) {
		antwort.innerHTML = "<pre>" + resObj.responseText + "</pre>";

		user.value = "";		user.disabled = true;
		pw.disabled = true;

		logout.style.display = "block";
		frage.style.display = "none";
		zurueck.style.display = "none";
	}
}

function plausi(evt) {
	let fehler = false;
	meldungenLeeren();
	// Kontrolle Passwort
	if (pw.value == "") {
		pwinfo.innerHTML = "Das Passwort darf nicht leer sein";
		pw.style.backgroundColor = "red";
		pw.value = "";
		pw.focus();
		fehler = true;
	}
	// Kontrolle Userid
	if (user.value.length < 8) {
		//Formular leeren, damit dir Bootstrap-Validation funktioniert
		user.value = "";
		user.focus();
		fehler = true;
	}

	if (!fehler) {
		fehler = false;
		sndReq();
	} else {
		loginForm.classList.add("was-validated");
		evt.stopPropagation();
		fehler = false;
		return false;
	}
}

function zuruecksetzen() {
	if (confirm("Das Formular wird zurückgesetzt.\nSind Sie sicher?")) {
		meldungenLeeren();
		f.action = "";
		f.reset();
		return false;
	}
	return false;
}

function meldungenLeeren() {
	userinfo.innerHTML = "";
	pwinfo.innerHTML = "";
	user.style.backgroundColor = "white";
	pw.style.backgroundColor = "white";
}

function getXhrError() {
  console.log("Error: " + xhr.status);
}

function init() {
	/* Variablen initialisieren */
	loginForm = document.querySelector("#loginForm");
	user = document.querySelector("#user");
	pw = document.querySelector("#pw");
	logout = document.querySelector("#logout");
	frage = document.querySelector("#frage");
	zurueck = document.querySelector("#zurueck");
	antwort = document.querySelector("#antwort");
	resObj = new XMLHttpRequest();
	/* Ereignisfunktionen registrieren */
	frage.addEventListener("click", plausi);
	zurueck.addEventListener("click", zuruecksetzen);
}

document.addEventListener("DOMContentLoaded", init);